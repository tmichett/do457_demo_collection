# report role

## Task example to use this role:

```
- name: Play to build a report
  ansible.builtin.include_role:
    name: tmichett.do457_demo_role
```
